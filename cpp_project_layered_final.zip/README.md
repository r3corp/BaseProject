# C++ Layered Project with ImGui, SQLite, Crow and GoogleTest

This is a layered C++ project structure that includes:

- Core logic and service layer
- UI with ImGui using SDL2/OpenGL
- Persistence using SQLite3
- GoogleTest for unit testing
- REST API layer (Crow - not implemented yet)
- CMake-based build system

## Structure

```
src/
  core/           # Business logic (e.g. UserService)
  db/             # Database access (SQLite)
  interfaces/     # Abstract interfaces
  models/         # Data models (e.g. User)
  ui/             # ImGui interface
  utils/          # Helper functions (optional)
tests/
  unit/           # GoogleTest unit tests
external/
  imgui/          # Add ImGui here manually or via git submodule
```

## Build Instructions

### Prerequisites

- CMake >= 3.14
- g++ or clang++
- SDL2
- OpenGL
- SQLite3
- GoogleTest

### Build

```bash
mkdir build
cd build
cmake ..
make
./main_app
```

To run tests:

```bash
./tests
```

## Run with Docker

Use the provided Dockerfile:

```bash
docker build -t cpp-imgui .
docker run -it --rm cpp-imgui
```
