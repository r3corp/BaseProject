#include "core/UserService.h"
#include "db/UserRepository.h"
#include "ui/UserForm.h"

int main() {
    // Setup do serviço
    auto repo = std::make_shared<UserRepository>();
    UserService service(repo);

    // Setup do ImGui + Loop
    // Aqui você chamaria renderUserForm(service) dentro do loop ImGui
    return 0;
}
