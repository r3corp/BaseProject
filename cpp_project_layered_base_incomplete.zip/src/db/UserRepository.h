#pragma once
#include <vector>
#include "../interfaces/IUserRepository.h"

class UserRepository : public IUserRepository {
    std::vector<User> users;
public:
    std::optional<User> findById(int id) override {
        for (auto& u : users) {
            if (u.id == id) return u;
        }
        return std::nullopt;
    }

    void save(const User& user) override {
        users.push_back(user);
    }
};
