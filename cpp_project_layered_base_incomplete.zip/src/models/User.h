#pragma once
#include <string>

struct User {
    int id;
    std::string name;
    std::string email;
};
